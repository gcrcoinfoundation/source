# Global Currency Reserve

This wallet is no longer maintained and has been abandoned by the developers. 

GCR will be utilized at a rate of 1:1 in the TREOS TRO token sale and, as such, the wallet files are being made publicly available.


